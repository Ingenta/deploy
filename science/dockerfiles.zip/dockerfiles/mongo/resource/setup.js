
rs.initiate();
quit();